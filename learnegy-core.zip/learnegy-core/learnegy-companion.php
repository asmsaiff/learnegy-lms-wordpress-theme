<?php
    /*
        Plugin Name: Learnegy Core
        Description: This plugin is the companion for the Learnegy theme, it runs and adds its enhancements only if the Learnegy theme is installed and active.
        Version: 1.0.0
        Author: Mamurjor IT
        Author URI: https://mamurjor.com
        Text Domain: learnegy-core
        License: GPLv2 or later
        License URI: http://www.gnu.org/licenses/gpl-2.0.html
    */

    if ( !defined( 'ABSPATH' ) ) {
        exit;
        // Exit if accessed directly.
    }

    global $base_url;
	$base_url = $_SERVER['HTTP_HOST'];
    define( 'CUSTOMIZER_REPEATER_VERSION', '1.1.0' );

echo $base_url;
	
    // define('LEARNEGY_PATH', plugins_url() . '/learnegy-core/');

    require 'inc/learnegy-repeater.php';
    require 'inc/config/learnegy-customizer-config.php';


    add_action( 'after_setup_theme', function()
    {
        
    add_filter('theme_page_templates', 'learnegy_add_page_template_to_dropdown');
    add_filter('template_include', 'learnegy_change_page_template');
    }, 5 );

    /**
     * Add page templates.
     *
     * @param  array  $templates  The list of page templates
     *
     * @return array  $templates  The modified list of page templates
     */
    function learnegy_add_page_template_to_dropdown($templates)
    {
        $templates['templates/front.php'] = __('Front Page', 'learnegy');

        return $templates;
    }

    function learnegy_change_page_template($template)
    {
        if (is_page()) {
            $meta = get_post_meta(get_the_ID());

            if (!empty($meta['_wp_page_template'][0]) && $meta['_wp_page_template'][0] != $template) {
                $template = $meta['_wp_page_template'][0];
            }
        }

        return $template;
    }