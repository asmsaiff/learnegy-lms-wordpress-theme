<?php
    add_action( 'after_setup_theme', function() {
        include '../../../lib/learnegy-customizer-panels.php';
    }, 5 );

    function learnegy_customize_register( $wp_customize ) {

        // Has to be at the top
        $wp_customize->register_panel_type( 'learnegy_WP_Customize_Panel' );

        $learnegy_theme_options = new learnegy_WP_Customize_Panel( $wp_customize, 'learnegy_theme_options', array(
            'title'             => 'learnegy Options',
            'capability'        => 'edit_theme_options',
            'priority'          => 1,
        ));
        $wp_customize->add_panel( $learnegy_theme_options );

        /**
         * ================================================
         * ================= Header Panel =================
         * ================================================
         */
        $learnegy_header = new learnegy_WP_Customize_Panel( $wp_customize, 'learnegy', array(
            'title'             => 'General',
            'capability'        => 'edit_theme_options',
            'panel'             => 'learnegy_theme_options',
            'priority'          => 1,
        ));
        $wp_customize->add_panel( $learnegy_header );

        require '../option-panel/op-header.php';
        require '../option-panel/op-footer.php';

        /**
         * ================================================
         * ================= Homepage Panel ===============
         * ================================================
         */
        $learnegy_homepage = new learnegy_WP_Customize_Panel( $wp_customize, 'learnegy_homepage', array(
            'title'             => 'Homepage Options',
            'capability'        => 'edit_theme_options',
            'panel'             => 'learnegy_theme_options',
            'priority'          => 2,
        ));
        $wp_customize->add_panel( $learnegy_homepage );

        require '../option-panel/op-info.php';
        require '../option-panel/op-notice.php';
        require '../option-panel/op-course.php';
        require '../option-panel/op-teacher.php';
        require '../option-panel/op-faq.php';
        require '../option-panel/op-event.php';
        require '../option-panel/op-blog.php';
        require '../option-panel/op-newsletter.php';
    }

    add_action( 'customize_register', 'learnegy_customize_register' );