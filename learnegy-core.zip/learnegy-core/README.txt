=== Learnegy Core ===
Developer: Saifullah Saif | saifullah(dot)co
Donate link: https://mamurjor.com
Tags: learnegy-theme-companion
Requires at least: 5.0.0
Tested up to: 5.9.2
Stable tag: 5.3
Requires PHP: 8.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Learnegy Theme Companion

== Description ==

This plugin is the companion for the Learnegy theme, it runs and adds its enhancements only if the Learnegy theme is installed and active. 

You don't need to configure anything after install and activate. Just activate and then you can see the full theme option in the customizer with front-page template sections.

== Installation ==

1. Upload the plugin to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress